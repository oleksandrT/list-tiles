$(document).ready(function () {

    // Init variables
    var $items = $( '.list-element' );

    function disableLinks() {
        var windowWidth = $(window).width();
        if ( windowWidth > 1023 ) {
            $('.list-element-title').addClass('link-disabled');
            $('.list-element-title a').click(function(e) {
                return false;
            });
        } else {
            $('.list-element-title').removeClass('link-disabled');
            $('.list-element-title a').unbind('click');
        }

    }

    function initEvents() {
        $items.on('click', 'span.description-close', function() {
            hideDescription();
            return false;
        });
    }

    function hideDescription() {
        console.log(' hideDescription ');
    }

    function init() {
        disableLinks();
        $(window).on('resize', disableLinks);
        
        initEvents();
    }

    init();



});